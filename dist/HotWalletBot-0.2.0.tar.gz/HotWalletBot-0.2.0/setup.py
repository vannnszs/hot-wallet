from setuptools import setup, find_packages

setup(
    name='HotWalletBot',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
        'selenium',
        # other dependencies here
    ],
    entry_points={
        'console_scripts': [
            'hotwalletbot = hotwalletbot.main:main',
        ],
    },
    long_description=open('README.rst').read(),  # Provide the path to your README.rst file
    author='vannszs',
    author_email='bevansatria@gmail.com',
    description='Automate your interactions with the HotWallet web application using Selenium.',
    url='https://github.com/vannszs/HotWalletBot',
)
